function Footer()
{
    return(
        <footer className="bg-vine">
            <p>&copy; {new Date().getFullYear()} NewsLetter</p>
            <div className="flex flex-row justify-between">
            <p>Mahima Sharma PE-47 1032222473</p>
            <p>Anushka Khedkar PE-34 1032222412</p>
            </div>
        </footer>
    )
}
export default Footer;